import { Directive } from '@angular/core';

@Directive({
  selector: '[appHammertime]'
})
export class HammertimeDirective {

  constructor() { }

}
