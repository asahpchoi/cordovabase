import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-occupation-search',
  templateUrl: './occupation-search.component.html',
  styleUrls: ['./occupation-search.component.css']
})
export class OccupationSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
