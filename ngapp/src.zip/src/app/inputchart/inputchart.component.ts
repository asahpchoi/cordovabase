import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inputchart',
  templateUrl: './inputchart.component.html',
  styleUrls: ['./inputchart.component.css']
})
export class InputchartComponent implements OnInit {
  tableView;
  constructor() { }

  ngOnInit() {
  }

}
