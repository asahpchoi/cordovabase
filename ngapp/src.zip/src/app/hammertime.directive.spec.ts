import { HammertimeDirective } from './hammertime.directive';

describe('HammertimeDirective', () => {
  it('should create an instance', () => {
    const directive = new HammertimeDirective();
    expect(directive).toBeTruthy();
  });
});
